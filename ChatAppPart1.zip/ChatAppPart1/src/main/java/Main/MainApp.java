/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main;

import java.util.Scanner;

public class MainApp {
    public static void main(String[] args){

        // Scanner allows the user to enter the information
        Scanner input = new Scanner(System.in);

        // Create an object of the Login class
        Login login = new Login();

        // =========================
        // REGISTRATION SECTION
        // =========================
        System.out.println("=== USER REGISTRATION ===");

        System.out.println("Enter a username:");
        String username = input.nextLine();

        System.out.println("Enter a password:");
        String password = input.nextLine();

        System.out.println("Enter phone number (+27):");
        String phoneNumber = input.nextLine();

        // Register user
        String registrationMessage = login.registerUser(username, password, phoneNumber);
        System.out.println(registrationMessage);

        // =========================
        // LOGIN SECTION
        // =========================
        System.out.println("\n=== USER LOGIN ===");

        System.out.println("Enter username:");
        String loginUsername = input.nextLine();

        System.out.println("Enter password:");
        String loginPassword = input.nextLine();

        // Call loginUser to check details
        boolean loggedIn = login.loginUser(loginUsername, loginPassword);

        // Print correct login message
        String loginMessage = login.returnLoginStatus(loggedIn);
        System.out.println(loginMessage);
    }
}